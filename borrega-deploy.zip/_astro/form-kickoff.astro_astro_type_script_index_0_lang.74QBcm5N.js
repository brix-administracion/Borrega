import{i as o}from"./web3form.Bn99F0NP.js";o("kickoff-form",{downloadSummary:!0});
