import{i as m}from"./web3form.Bn99F0NP.js";m("sumate-form");
